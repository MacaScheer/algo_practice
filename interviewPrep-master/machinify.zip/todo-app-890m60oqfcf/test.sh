#!/bin/bash
echo "FS_SCORE:100%"
