/**
 * TodoListWidget
 *
 * (c) Machinify 2018. All rights reserved.
 * @flow
 **/
"use strict";
import * as React from "react";
import TodoList from "../models/TodoList.js";
import Todo from "../models/Todo.js";
import TodoWidget from "./TodoWidget.react.js";

export type TodoListWidgetProps = {
  todoList: TodoList
};

export default class TodoListWidget extends React.Component<
  TodoListWidgetProps,
  void
> {
  static defaultProps: void;

  constructor(props: TodoListWidgetProps) {
    super(props);
    autobind(this, "_handleAddTodo", "_handleDelete");
    this.state = {
      loading: true
    };
  }

  componentDidMount() {
    this.demoAsyncCall().then(() => this.setState({ loading: false }));
    this.props.todoList.load().then(
      () => this.forceUpdate(),
      err =>
        // debugger;
        JSON.stringify(err)
    );
  }

  render(): React.Node {
    if (this.state.loading) {
      //debugger;
      return <div>Loading....</div>; // render loading msg
    }
    debugger;
    return (
      <React.Fragment>
        <div>{this.props.err}</div>
        <ol>
          {this.props.todoList.list.map((todo, i) => (
            <li key={i}>
              <TodoWidget todo={todo} />
              <button onClick={e => this._handleDelete(e, i)}>Delete</button>
            </li>
          ))}
        </ol>
        <input type="button" value="Add Todo" onClick={this._handleAddTodo} />
      </React.Fragment>
    );
  }

  _handleDelete(e, i) {
    e.preventDefault();
    this.props.todoList.removeTodo(i);
    this.forceUpdate();
  }

  _handleAddTodo() {
    const todo = new Todo();
    todo.title = "New TODO";
    this.props.todoList.addTodo(todo);
    todo.save();
    this.forceUpdate();
  }
  demoAsyncCall() {
    return new Promise(resolve => setTimeout(() => resolve(), 2500));
  }
}
