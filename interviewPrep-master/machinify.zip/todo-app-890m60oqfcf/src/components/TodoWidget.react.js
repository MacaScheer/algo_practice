/**
 * TodoWidget
 *
 * (c) Machinify 2018. All rights reserved.
 * @flow
 **/
"use strict";
import * as React from "react";
import Todo from "../models/Todo.js";
import { SSL_OP_EPHEMERAL_RSA } from "constants";

export type TodoWidgetProps = {
  todo: Todo
};

export type TodoWidgetState = {
  title: string
};

export default class TodoWidget extends React.Component<
  TodoWidgetProps,
  TodoWidgetState
> {
  static defaultProps: void;

  constructor(props: TodoWidgetProps) {
    super(props);
    autobind(this, "_handleTitleChanged", "_handleTitleBlur");
    this.state = {
      title: this.props.todo.title
    };
  }

  render(): React.Node {
    return (
      <div>
        <input
          type="text"
          value={this.state.title}
          onChange={this._handleTitleChanged}
          onBlur={this._handleTitleBlur}
        />
      </div>
    );
  }

  _handleTitleChanged(event: Event) {
    //  debugger;
    if (event.target instanceof HTMLInputElement) {
      this.setState({ title: event.target.value });
    }
  }

  _handleTitleBlur() {
    let validTitle = validate(this.state.title);
    this.props.todo.title = this.state.title;
    this.props.todo.save();
   
  }

  validate(title) {
    alpha = "abcdefghijklmnopqrstuvwxyz";
    nums = "0123456789";
    alphaCaps = alpha.toUpperCase().split("");
    //alpha = alpha.split("");
    //nums = nums.split("");

    title = title.split("");
    title.forEach(ch => )
  }

  
}
